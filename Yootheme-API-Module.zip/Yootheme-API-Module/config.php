<?php

$app->load(__DIR__ . '/modules/*/bootstrap.php');

return [];